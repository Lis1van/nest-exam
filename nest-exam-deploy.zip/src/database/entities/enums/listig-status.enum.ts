export enum ListingStatus {
  MODERATION = 'moderation',
  ACTIVE = 'active',
  REJECTED = 'rejected',
  CLOSED = 'closed',
}
