export class Statistic {}
