export class CreateStatisticDto {}
