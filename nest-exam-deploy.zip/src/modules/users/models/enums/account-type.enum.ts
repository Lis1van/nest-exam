export enum AccountTypeEnum {
  BASIC = 'basic',
  PREMIUM = 'premium',
}
